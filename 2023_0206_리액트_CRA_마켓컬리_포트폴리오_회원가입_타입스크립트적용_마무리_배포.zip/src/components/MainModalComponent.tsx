import React from 'react';

function MainModalComponent({mainModalState}:any) {
    return (
        <div>
            <h1>MainModalComponent</h1>
        </div>
    );
};
export default MainModalComponent;