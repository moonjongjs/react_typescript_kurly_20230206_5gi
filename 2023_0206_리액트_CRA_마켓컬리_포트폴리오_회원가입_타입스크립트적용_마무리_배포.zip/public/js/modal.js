(function($, window, document){

    const Kurly = {
        init: function(){
            this.modal();            
        },
        modal: function(){

        }
    }

    Kurly.init();
 

})(jQuery, window, document);